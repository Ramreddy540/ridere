package com.example.kotlinapplication

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.AdapterView
import android.widget.Gallery
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class AnimalGallery : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var animalGallery: Gallery
    private lateinit var textToSpeech: TextToSpeech

    private val animal= listOf(
        Animal("Tiger",R.drawable.tiger),
        Animal("Cheetha",R.drawable.cheetha),
        Animal("Chimpanzee",R.drawable.champanzee),
        Animal("Panda",R.drawable.panda),
        Animal("Fox",R.drawable.fox)
    )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_animal_gallery)
        imageView=findViewById(R.id.imageView)
        animalGallery=findViewById(R.id.AnimalGallery)
        textToSpeech=TextToSpeech(this){status ->
            if(status!=TextToSpeech.ERROR){
                textToSpeech.language= Locale.US
            }
        }
        val animalAdapter=Galleryadapter(this,animal)
        animalGallery.adapter=animalAdapter

        animalGallery.onItemClickListener=AdapterView.OnItemClickListener{_,_,position,_ ->
            imageView.setImageResource(animal[position].imageResource)
            speak(animal[position].name)
            showToast(animal[position].name)
        }
    }
    private fun showToast(text:String) {
        Toast.makeText(this,text,Toast.LENGTH_SHORT).show()
    }
    private fun speak(text: String){
       textToSpeech.speak(text,TextToSpeech.QUEUE_FLUSH,null,null)
    }

    override fun onDestroy() {
        super.onDestroy()
        textToSpeech.shutdown()
    }
}