package com.example.kotlinapplication
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class DashBoardActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dash_board)

        val c1= findViewById<CardView>(R.id.card1)
        val c2= findViewById<CardView>(R.id.card2)
        val c3= findViewById<CardView>(R.id.card3)
        val c4= findViewById<CardView>(R.id.card4)
        val c5= findViewById<CardView>(R.id.card5)
        val c6= findViewById<CardView>(R.id.card6)


        c1.setOnClickListener{
            val i = Intent(this,MusicPlayerActivity::class.java)
            startActivity(i)
        }

        c2.setOnClickListener{
            val i = Intent(this,PhoneCallActivity::class.java)
            startActivity(i)
        }

        c3.setOnClickListener{
            val i = Intent(this,CameraActivity::class.java)
            startActivity(i)
        }

        c4.setOnClickListener{
            val i = Intent(this,CalculatorActivity::class.java)
            startActivity(i)
        }

        c5.setOnClickListener{
            val i = Intent(this,VideoView::class.java)
            startActivity(i)
        }

        c6.setOnClickListener{
            val i = Intent(this,MapActivity::class.java)
            startActivity(i)
        }










    }
}