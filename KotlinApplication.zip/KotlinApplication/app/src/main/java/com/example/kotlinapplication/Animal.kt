package com.example.kotlinapplication

class Animal (val name: String,val imageResource:Int)