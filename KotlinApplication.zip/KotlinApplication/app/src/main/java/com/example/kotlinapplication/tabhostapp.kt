package com.example.kotlinapplication

import android.os.Bundle
import android.widget.TabHost
import androidx.appcompat.app.AppCompatActivity

class tabhostapp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tabhostapp)


        val tabhost = findViewById<TabHost>(R.id.tabhost)
        tabhost.setup()
        var spec = tabhost.newTabSpec("Tab One")
        spec.setContent(R.id.tab1)
        spec.setIndicator("Tab One")
        tabhost.addTab(spec)
        spec = tabhost.newTabSpec("Tab Two")
        spec.setContent(R.id.tab2)
        spec.setIndicator("Tab Two")
        tabhost.addTab(spec)
        spec = tabhost.newTabSpec("Tab Three")
        spec.setContent(R.id.tab3)
        spec.setIndicator("Tab Three")
        tabhost.addTab(spec)
    }
}
