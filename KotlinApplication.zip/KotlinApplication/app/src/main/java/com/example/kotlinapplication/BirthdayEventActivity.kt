package com.example.kotlinapplication

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

@Suppress("NAME_SHADOWING")
class BirthdayEventActivity : AppCompatActivity() {
    private lateinit var Button : Button
    private lateinit var s1:String
    private lateinit var s2:String
    @SuppressLint("WrongViewCast", "CutPasteId", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_birthday_event)
        val datePicker = findViewById<DatePicker>(R.id.datepicker)
        val timePicker = findViewById<TimePicker>(R.id.timePicker)


        val today = Calendar.getInstance()

        datePicker.init(
            today.get(Calendar.YEAR),
            today.get(Calendar.MONTH),
            today.get(Calendar.DAY_OF_MONTH)

        ) { view, year, month, day ->
            val month = month + 1
            val msg1 = "You Selected: $day/$month/$year"

        }
        timePicker.hour =today.get(Calendar.HOUR_OF_DAY)
            timePicker.minute = today.get(Calendar.MINUTE)

        Button= findViewById(R.id.button3)
        Button.setOnClickListener {

            val selectdate = Calendar.getInstance()
            selectdate.set(
                datePicker.year,
                datePicker.month,
                datePicker.dayOfMonth,
                timePicker.hour,
                timePicker.minute
            )

            val dateFormat = SimpleDateFormat("dd/MM/yyyy hh:mm a",Locale.getDefault())
            val selectdateTime = dateFormat.format(selectdate.time)
            Toast.makeText(applicationContext,"Selectted date and time:$selectdateTime",Toast.LENGTH_SHORT).show()


        }



    }

}