package com.example.kotlinapplication

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ImageButton
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity

class PhoneCallActivity : AppCompatActivity() {
    lateinit var radioGroup: RadioGroup
    lateinit var call:ImageButton
    lateinit var sms: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_phone_call)


        radioGroup = findViewById(R.id.radioGroup2)
        call = findViewById(R.id.callnow)
        sms = findViewById(R.id.sms)

        call.setOnClickListener{
            val selectedbtn:Int=radioGroup.checkedRadioButtonId
            val radiobutton=findViewById<RadioButton>(selectedbtn)
            val phoneNumber = when (radiobutton.text) {
                "Police" -> "100"
                "Fire Station" -> "101"
                "Hospital" ->"104"
                "ATM" ->"9999999999"
                "Fuel Station" -> "9160088453"

                else -> ""
            }
            if (phoneNumber.isNotEmpty()) {
                val dialIntent = Intent(Intent.ACTION_DIAL)
                dialIntent.data = Uri.parse("tel:$phoneNumber")
                startActivity(dialIntent)
            } else {
                val dialIntent = Intent(Intent.ACTION_DIAL)
                dialIntent.data = Uri.parse("tel:$phoneNumber")
                startActivity(dialIntent)
            }
        }
        sms.setOnClickListener {
            val selectedbtn:Int=radioGroup.checkedRadioButtonId
            val radiobutton=findViewById<RadioButton>(selectedbtn)
            val phoneNumber = when (radiobutton.text) {
                "Police" -> "100"
                "Fire Station" -> "101"
                "Hospital" ->"104"
                "ATM" ->"9999999999"
                "Fuel Station" -> "9160088453"

                else -> ""
            }
            if (phoneNumber.isBlank()) {
                val sendIntent = Intent(Intent.ACTION_SENDTO)
                sendIntent.data = Uri.parse("sms:$phoneNumber")
                startActivity(sendIntent)
            } else {
                val sendIntent = Intent(Intent.ACTION_SENDTO)
                sendIntent.data = Uri.parse("sms:$phoneNumber")
                startActivity(sendIntent)
            }
        }
    }
}

