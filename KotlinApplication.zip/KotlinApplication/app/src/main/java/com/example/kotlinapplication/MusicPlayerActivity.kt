package com.example.kotlinapplication

import android.annotation.SuppressLint
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MusicPlayerActivity : AppCompatActivity() {
    private var mp: MediaPlayer?=null
    private var currentSong: MutableList<Int> = mutableListOf(R.raw.ringtone)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music_player)
        controlSound(currentSong[0])
    }
    @SuppressLint("WrongViewCast")
    private fun controlSound(id: Int) {

        val mplay=findViewById<FloatingActionButton>(R.id.mplay)
        mplay.setOnClickListener {
            if (mp==null){
                mp=MediaPlayer.create(this,id)
                Log.d("Musicplayer","ID:${ mp!!.audioSessionId }")
                initialliseSeekBar()
            }
            mp?.start()
            Log.d("Musicplayer","Duration:${mp!!.duration/1000} seconds")
        }
        val mpause = findViewById<FloatingActionButton>(R.id.mpause)
        mpause.setOnClickListener {
            if (mp!=null) mp?.pause()
            Log.d("Musicplayer","Paused at:${mp!!.currentPosition/1000} seconds")
        }
        val mstop=findViewById<FloatingActionButton>(R.id.mstop)
        mstop.setOnClickListener {
            if (mp!=null){
                mp?.stop()
                mp?.reset()
                mp?.release()
                mp=null
            }
        }
        val sb=findViewById<SeekBar>(R.id.sb)
        sb.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) mp?.seekTo(progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {

            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {

            }

        })
    }
    private fun initialliseSeekBar() {
        val sp=findViewById<SeekBar>(R.id.sb)
        sp.max= mp!!.duration
        val handler=Handler()
        handler.postDelayed(object : Runnable {
            @SuppressLint("SuspiciousIndentation")
            override fun run() {
                try {
                    sp.progress= mp!!.currentPosition
                    handler.postDelayed(this,1000)
                }catch (e:java.lang.Exception){
                    sp.progress=0
                }
            }


        },0)
    }
}