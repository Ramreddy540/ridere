package com.example.kotlinapplication

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView


class Galleryadapter(private val context:Context, private val animals : List<Animal>) : BaseAdapter(){
    override fun getCount() = animals.size

    override fun getItem(position:Int)=animals[position]

    override fun getItemId(position: Int)=position.toLong()


    override fun getView(position: Int,convertView:View?,parent:ViewGroup?):View{
        val view =convertView?: LayoutInflater.from(context).inflate(R.layout.gallery_item,parent,false)
        view.findViewById<ImageView>(R.id.galleryimage).setImageResource(animals[position].imageResource)

        return view
    }

}