package com.example.kotlinapplication

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var c1=findViewById<CardView>(R.id.c1)
        var c2=findViewById<CardView>(R.id.c2)
        var c3=findViewById<CardView>(R.id.c3)
        var c4=findViewById<CardView>(R.id.c4)
        var c5=findViewById<CardView>(R.id.c5)
        var c6=findViewById<CardView>(R.id.c6)
        var c7=findViewById<CardView>(R.id.c7)
        var c8=findViewById<CardView>(R.id.c8)


        c1.setOnClickListener {
            val i1= Intent(this,InternetActivity::class.java)
            startActivity(i1)
      }

        c2.setOnClickListener {
            val i1= Intent(this,PhoneCallActivity::class.java)
            startActivity(i1)
        }

        c3.setOnClickListener {
            val i1= Intent(this,Ratingbar::class.java)
            startActivity(i1)
        }

        c4.setOnClickListener {
            val i1= Intent(this,BirthdayEventActivity::class.java)
            startActivity(i1)
        }

        c5.setOnClickListener {
            val i1= Intent(this,AnimalGallery::class.java)
            startActivity(i1)
        }

        c6.setOnClickListener {
            val i1= Intent(this,TextToSpeech::class.java)
            startActivity(i1)
        }

        c7.setOnClickListener {
            val i1= Intent(this,CameraActivity::class.java)
            startActivity(i1)
        }

        c8.setOnClickListener {
            val i1= Intent(this,MusicPlayerActivity::class.java)
            startActivity(i1)
        }









    }
}