package com.example.kotlinapplication

import androidx.appcompat.app.AppCompatActivity
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.os.Bundle

class ProgessabarActivity : AppCompatActivity() {
    lateinit var showProgressBtn: Button
    lateinit var loadingPB: ProgressBar
    var isProgressVisible = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_progessa_bar)
        showProgressBtn = findViewById(R.id.idBtnDisplayProgress)
        loadingPB = findViewById(R.id.idPBLoading)
        loadingPB = findViewById(R.id.idPBLoading)
        showProgressBtn.setOnClickListener {
            if (isProgressVisible) {
                showProgressBtn.text = "Show Progress Bar"
                loadingPB.visibility = View.GONE
                isProgressVisible = false
            } else {
                isProgressVisible = true
                showProgressBtn.text = "Hide Progress Bar"
                loadingPB.visibility = View.VISIBLE
            }
        }
    }
}
