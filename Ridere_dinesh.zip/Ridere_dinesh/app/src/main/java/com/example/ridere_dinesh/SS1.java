package com.example.ridere_dinesh;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.os.Bundle;
import android.view.MenuItem;
public class SS1 extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ss1);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here.
         int id = item.getItemId();
         if (id == android.R.id.home)
         {
        // Handle the back button click
         onBackPressed();
         return true;
         }
         return super.onOptionsItemSelected(item);
         }
         }