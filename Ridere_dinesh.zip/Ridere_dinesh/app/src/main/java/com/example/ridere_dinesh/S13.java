package com.example.ridere_dinesh;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class S13 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s13);
    }
}