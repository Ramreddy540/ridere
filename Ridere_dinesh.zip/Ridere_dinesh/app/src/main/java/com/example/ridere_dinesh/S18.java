package com.example.ridere_dinesh;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class S18 extends AppCompatActivity {
    private TextView pickDateBtn;
    private TextView selectedDateTV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s18);

        pickDateBtn = findViewById(R.id.datePicker);
        selectedDateTV = findViewById(R.id.datePicker);

        pickDateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        S18.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                SimpleDateFormat sdf = new SimpleDateFormat("EEEE", Locale.getDefault());
                                Calendar selectedCalendar = Calendar.getInstance();
                                selectedCalendar.set(year, monthOfYear, dayOfMonth);

                                String selectedDayOfWeek = sdf.format(new Date(selectedCalendar.getTimeInMillis()));

                                String selectedDate = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                                String formattedDate = selectedDate + " (" + selectedDayOfWeek + ")";
                                selectedDateTV.setText(formattedDate);
                            }
                        },
                        year, month, day);

                datePickerDialog.show();
            }
        });
    }
}
